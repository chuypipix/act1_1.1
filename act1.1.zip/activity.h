// =================================================================
//
// File: activity.h
// Author:
// Date:
//
// =================================================================
#ifndef ACTIVITY_H
#define ACTIVITY_H

// =================================================================
// sumaIterativa. Calculate the sum from 1 to n with an iterative
// method.
//
// @param n	The maximum limit of the sum.
// @return	The result of the addition from 1 to n.
// @Complexity The complexity of the first algorithm is linear (big O of n)


// =================================================================
unsigned int sumaIterativa(unsigned int n)
{
    if (n == 1){
        return 1;
    }
    int cont = 0;
    for (int i = 0; i <= n; i++)
    {
       cont+= i;
    }
    return cont;
}


// =================================================================
// sumaRecursiva. Calculate the sum from 1 to n with an recursive
// method.
//
// @param n	The maximum limit of the sum.
// @return	The result of the addition from 1 to n.
// @Complexity	The complexity of the second algorithm is linear (big O of n)
// =================================================================
unsigned int sumaRecursiva(unsigned int n)
{
    if (n == 1){
        return 1;
    }
    if (n == 0)
    {
        return 0;
    }
    else
    {
        return n + sumaRecursiva(n - 1);
    }
}

// =================================================================
// sumaDirecta. Calculate the sum from 1 to n with a mathematical
// method.
//
// @param n	The maximum limit of the sum.
// @return	The result of the addition from 1 to n.
// @Complexity	??
// =================================================================
unsigned int sumaDirecta(unsigned int n){
    if (n == 1){
        return 1;
    }
    double div= n / 2;
    div = ceil(div);
    return ((n * div) + div);
}
#endif /* ACTIVITY_H */
